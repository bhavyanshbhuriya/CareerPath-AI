import plotly.graph_objects as go
import plotly.express as px
import numpy as np

# Create figure
fig = go.Figure()

# Define layer positions and colors
layer_colors = ['#1FB8CD', '#DB4545', '#2E8B57', '#5D878F', '#D2BA4C', '#964325']
layer_names = ['User Input', 'AI Processing', 'Data Sources', 'Features', 'Output', 'Support']

# Layer 1: User Input (y=0.5)
user_inputs = [
    {'name': 'Student Profile', 'x': 1, 'y': 0.5},
    {'name': 'Psychometric', 'x': 3, 'y': 0.5},
    {'name': 'Aptitude Tests', 'x': 5, 'y': 0.5},
    {'name': 'Preferences', 'x': 7, 'y': 0.5}
]

# Layer 2: AI Processing (y=1.5)
ai_processing = [
    {'name': 'NLP Engine', 'x': 1, 'y': 1.5},
    {'name': 'ML Algorithms', 'x': 3, 'y': 1.5},
    {'name': 'Predictive AI', 'x': 5, 'y': 1.5},
    {'name': 'Recommend Eng', 'x': 7, 'y': 1.5}
]

# Layer 3: Data Sources (y=2.5)
data_sources = [
    {'name': 'Govt College', 'x': 0.5, 'y': 2.5},
    {'name': 'Job Market', 'x': 2.5, 'y': 2.5},
    {'name': 'Industry Data', 'x': 4.5, 'y': 2.5},
    {'name': 'Scholarship', 'x': 6.5, 'y': 2.5},
    {'name': 'Admission Req', 'x': 8.5, 'y': 2.5}
]

# Layer 4: Features (y=3.5)
features = [
    {'name': 'Career Recom', 'x': 1, 'y': 3.5},
    {'name': 'College Match', 'x': 3, 'y': 3.5},
    {'name': 'Roadmap Gen', 'x': 5, 'y': 3.5},
    {'name': 'Skill Analysis', 'x': 7, 'y': 3.5}
]

# Layer 5: Output (y=4.5)
outputs = [
    {'name': 'Web App', 'x': 1.5, 'y': 4.5},
    {'name': 'Mobile App', 'x': 3.5, 'y': 4.5},
    {'name': 'Chatbot', 'x': 5.5, 'y': 4.5},
    {'name': 'Dashboard', 'x': 7.5, 'y': 4.5}
]

# Layer 6: Support (y=5.5)
support = [
    {'name': 'Blockchain', 'x': 2, 'y': 5.5},
    {'name': 'Multi-language', 'x': 4.5, 'y': 5.5},
    {'name': 'Offline Mode', 'x': 7, 'y': 5.5}
]

# Function to add rectangles with text
def add_rectangle(fig, x, y, text, color, width=1.2, height=0.3):
    fig.add_shape(
        type="rect",
        x0=x-width/2, y0=y-height/2,
        x1=x+width/2, y1=y+height/2,
        fillcolor=color,
        line=dict(color="white", width=2),
    )
    fig.add_annotation(
        x=x, y=y,
        text=text,
        showarrow=False,
        font=dict(color="white", size=10, family="Arial Bold"),
        align="center"
    )

# Function to add arrows between layers
def add_arrow(fig, x1, y1, x2, y2, color="#666666"):
    fig.add_annotation(
        x=x2, y=y2,
        ax=x1, ay=y1,
        xref="x", yref="y",
        axref="x", ayref="y",
        showarrow=True,
        arrowhead=2,
        arrowsize=1,
        arrowwidth=2,
        arrowcolor=color,
        text=""
    )

# Add all components as rectangles
for item in user_inputs:
    add_rectangle(fig, item['x'], item['y'], item['name'], layer_colors[0])

for item in ai_processing:
    add_rectangle(fig, item['x'], item['y'], item['name'], layer_colors[1])

for item in data_sources:
    add_rectangle(fig, item['x'], item['y'], item['name'], layer_colors[2], width=1.0)

for item in features:
    add_rectangle(fig, item['x'], item['y'], item['name'], layer_colors[3])

for item in outputs:
    add_rectangle(fig, item['x'], item['y'], item['name'], layer_colors[4])

for item in support:
    add_rectangle(fig, item['x'], item['y'], item['name'], layer_colors[5])

# Add arrows showing flow between layers
# User Input to AI Processing
for ui in user_inputs:
    for ai in ai_processing:
        if abs(ui['x'] - ai['x']) <= 2:  # Connect nearby components
            add_arrow(fig, ui['x'], ui['y']+0.15, ai['x'], ai['y']-0.15)

# AI Processing to Data Sources (selective connections)
connections = [(1, 0.5), (3, 2.5), (5, 4.5), (7, 6.5), (7, 8.5)]
for ai_x, data_x in connections:
    add_arrow(fig, ai_x, 1.65, data_x, 2.35)

# AI Processing to Features
for ai in ai_processing:
    for feat in features:
        if abs(ai['x'] - feat['x']) <= 1:
            add_arrow(fig, ai['x'], ai['y']+0.15, feat['x'], feat['y']-0.15)

# Features to Output
for feat in features:
    for out in outputs:
        if abs(feat['x'] - out['x']) <= 1:
            add_arrow(fig, feat['x'], feat['y']+0.15, out['x'], out['y']-0.15)

# Output to Support (selective connections)
support_connections = [(1.5, 2), (3.5, 4.5), (5.5, 4.5), (7.5, 7)]
for out_x, sup_x in support_connections:
    add_arrow(fig, out_x, 4.65, sup_x, 5.35)

# Add layer labels on the left
layer_positions = [0.5, 1.5, 2.5, 3.5, 4.5, 5.5]
for i, (name, pos) in enumerate(zip(layer_names, layer_positions)):
    fig.add_annotation(
        x=-0.5, y=pos,
        text=f"<b>{name}</b>",
        showarrow=False,
        font=dict(color=layer_colors[i], size=12, family="Arial Bold"),
        align="right",
        textangle=-90
    )

# Add legend using invisible traces
for i, (name, color) in enumerate(zip(layer_names, layer_colors)):
    fig.add_trace(go.Scatter(
        x=[None], y=[None],
        mode='markers',
        marker=dict(size=15, color=color, symbol='square'),
        name=name,
        showlegend=True
    ))

# Update layout
fig.update_layout(
    title="Career Advisor System Flow",
    showlegend=True,
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    plot_bgcolor='white',
    xaxis=dict(range=[-1, 9.5], showgrid=False, showticklabels=False, zeroline=False),
    yaxis=dict(range=[0, 6], showgrid=False, showticklabels=False, zeroline=False)
)

fig.update_traces(cliponaxis=False)

# Save the charts
fig.write_image("chart.png")
fig.write_image("chart.svg", format="svg")

print("Updated flowchart saved successfully!")