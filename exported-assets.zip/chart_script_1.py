import pandas as pd
import plotly.graph_objects as go
import plotly.express as px

# Create the data from the provided JSON
data = {
    "Approach": ["Traditional Career Counseling", "Traditional Career Counseling", "Traditional Career Counseling", "Traditional Career Counseling", "Traditional Career Counseling", "Traditional Career Counseling", "Traditional Career Counseling", "Traditional Career Counseling",
                 "Online Career Platforms (Generic)", "Online Career Platforms (Generic)", "Online Career Platforms (Generic)", "Online Career Platforms (Generic)", "Online Career Platforms (Generic)", "Online Career Platforms (Generic)", "Online Career Platforms (Generic)", "Online Career Platforms (Generic)",
                 "AI-Powered Career Guidance", "AI-Powered Career Guidance", "AI-Powered Career Guidance", "AI-Powered Career Guidance", "AI-Powered Career Guidance", "AI-Powered Career Guidance", "AI-Powered Career Guidance", "AI-Powered Career Guidance",
                 "Our Proposed Solution", "Our Proposed Solution", "Our Proposed Solution", "Our Proposed Solution", "Our Proposed Solution", "Our Proposed Solution", "Our Proposed Solution", "Our Proposed Solution"],
    "Criteria": ["Personalization Level", "Real-time Data Integration", "Government Focus", "Accessibility (Rural Areas)", "Cost Effectiveness", "Scalability", "Multi-language Support", "Offline Capability",
                 "Personalization Level", "Real-time Data Integration", "Government Focus", "Accessibility (Rural Areas)", "Cost Effectiveness", "Scalability", "Multi-language Support", "Offline Capability",
                 "Personalization Level", "Real-time Data Integration", "Government Focus", "Accessibility (Rural Areas)", "Cost Effectiveness", "Scalability", "Multi-language Support", "Offline Capability",
                 "Personalization Level", "Real-time Data Integration", "Government Focus", "Accessibility (Rural Areas)", "Cost Effectiveness", "Scalability", "Multi-language Support", "Offline Capability"],
    "Score": [3, 2, 4, 3, 2, 2, 3, 1, 6, 7, 2, 6, 8, 9, 4, 3, 8, 8, 3, 7, 9, 9, 6, 4, 9, 9, 10, 9, 9, 10, 9, 8]
}

df = pd.DataFrame(data)

# Abbreviate criteria names to fit 15 character limit
criteria_mapping = {
    "Personalization Level": "Personal Lvl",
    "Real-time Data Integration": "Real-time Data",
    "Government Focus": "Gov Focus",
    "Accessibility (Rural Areas)": "Rural Access",
    "Cost Effectiveness": "Cost Effect",
    "Scalability": "Scalability",
    "Multi-language Support": "Multi-lang",
    "Offline Capability": "Offline Cap"
}

df['Criteria_Short'] = df['Criteria'].map(criteria_mapping)

# Abbreviate approach names to fit 15 character limit
approach_mapping = {
    "Traditional Career Counseling": "Traditional",
    "Online Career Platforms (Generic)": "Online Generic",
    "AI-Powered Career Guidance": "AI-Powered",
    "Our Proposed Solution": "Our Solution"
}

df['Approach_Short'] = df['Approach'].map(approach_mapping)

# Define colors using the brand colors in order
colors = ['#1FB8CD', '#DB4545', '#2E8B57', '#5D878F']

# Create horizontal bar chart
fig = go.Figure()

approaches = df['Approach_Short'].unique()
criteria_order = list(criteria_mapping.values())

for i, approach in enumerate(approaches):
    approach_data = df[df['Approach_Short'] == approach]
    approach_data = approach_data.set_index('Criteria_Short').reindex(criteria_order)
    
    fig.add_trace(go.Bar(
        name=approach,
        y=approach_data.index,
        x=approach_data['Score'],
        orientation='h',
        marker_color=colors[i],
        hovertemplate='<b>%{fullData.name}</b><br>' +
                      '%{y}: %{x}/10<extra></extra>'
    ))

# Update layout
fig.update_layout(
    title="Career Guidance Approaches Comparison",
    xaxis_title="Score (1-10)",
    yaxis_title="Criteria",
    barmode='group',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Update traces
fig.update_traces(cliponaxis=False)

# Update x-axis to show scale 0-10
fig.update_xaxes(range=[0, 10], dtick=1)

# Save as both PNG and SVG
fig.write_image("chart.png")
fig.write_image("chart.svg", format="svg")

fig.show()